package br.com.fiap.dao;

import br.com.fiap.entity.Customer;

//INTERFACE PODE HERDAR MAIS DE UMA INTERFACE
public interface CustomerDAO extends GenericDAO<Customer, Integer> {

}
