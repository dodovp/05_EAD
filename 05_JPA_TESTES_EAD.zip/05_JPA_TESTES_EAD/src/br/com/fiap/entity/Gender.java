package br.com.fiap.entity;

public enum Gender {

	Male, Female;
}
