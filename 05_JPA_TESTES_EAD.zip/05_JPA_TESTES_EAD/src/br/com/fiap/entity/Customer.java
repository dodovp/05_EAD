package br.com.fiap.entity;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table (name="TB_CUSTOMER")
@SequenceGenerator(name="customer", sequenceName="SQ_T_CUSTOMER",allocationSize=1)

public class Customer {
	
	@Id
	@GeneratedValue(generator="customer", strategy=GenerationType.SEQUENCE)
	@Column(name="id_customer", length=5)
	private int id;
	
	@Column(name="nm_customer", nullable=false, length=50)
	private String name;
	
	@Temporal(value=TemporalType.DATE)
	@Column(name="dt_birthday", nullable=false, length=10)
	private Calendar birthdayDate;
	
	@Enumerated(EnumType.STRING)
	@Column(name="ds_gender", nullable=false)
	private Gender gender;
	
	@Lob
	@Column(name="fl_profile", nullable=true)
	private byte[] profileImage;
	
	public Customer(String name, Calendar birthdayDate, Gender gender, byte[] profileImage) {
		super();
		this.name = name;
		this.birthdayDate = birthdayDate;
		this.gender = gender;
		this.profileImage = profileImage;
	}

	public Customer() {
		super();
	}

	public Customer(int id, String name, Calendar birthdayDate, Gender gender, byte[] profileImage) {
		super();
		this.id = id;
		this.name = name;
		this.birthdayDate = birthdayDate;
		this.gender = gender;
		this.profileImage = profileImage;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Calendar getBirthdayDate() {
		return birthdayDate;
	}

	public void setBirthdayDate(Calendar birthdayDate) {
		this.birthdayDate = birthdayDate;
	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public byte[] getProfileImage() {
		return profileImage;
	}

	public void setProfileImage(byte[] profileImage) {
		this.profileImage = profileImage;
	}
	
	
	
}
