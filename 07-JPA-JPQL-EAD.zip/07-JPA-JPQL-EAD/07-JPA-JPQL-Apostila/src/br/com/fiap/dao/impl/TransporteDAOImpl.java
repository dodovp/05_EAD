package br.com.fiap.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;

import br.com.fiap.dao.TransporteDAO;
import br.com.fiap.entity.Transporte;

public class TransporteDAOImpl extends GenericDAOImpl<Transporte,Integer> implements TransporteDAO{

	public TransporteDAOImpl(EntityManager entityManager) {
		super(entityManager);
	}

	@Override
	public List<Transporte> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Transporte> getAllByTransporte(String name) {
		// TODO Auto-generated method stub
		return null;
	}

}
