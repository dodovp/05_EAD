package br.com.fiap.entity;

public enum TipoPagamento {
	BOLETO, DINHEIRO, CARTAO_CREDITO, CARTAO_DEBITO
}
