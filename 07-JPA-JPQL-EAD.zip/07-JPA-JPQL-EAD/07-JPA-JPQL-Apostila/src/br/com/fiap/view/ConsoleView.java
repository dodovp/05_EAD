package br.com.fiap.view;


public class ConsoleView {

	public static void main(String[] args) {

	}

}
