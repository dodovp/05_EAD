package br.com.fiap.teste;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

import java.util.List;

import javax.persistence.EntityManager;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import br.com.fiap.dao.ClienteDAO;
import br.com.fiap.dao.EntityManagerFactorySingleton;
import br.com.fiap.dao.impl.ClienteDAOImpl;
import br.com.fiap.entity.Cliente;

class ClienteDAOTest {
	private static ClienteDAO dao;
	
	@BeforeAll
	public static void iniciar() {
		EntityManager em = EntityManagerFactorySingleton.getInstance().createEntityManager();
		dao = new ClienteDAOImpl(em);
	}
	
	@Test
	void getAllByNameTest() {
		List<Cliente> lista = dao.getAllByName("Ma");
		assertNotEquals(0, lista.size());
		//Validar se os clientes retornados est�o corretos
		for(Cliente cliente : lista) {
			assertTrue(cliente.getNome().contains("Ma"));
		}
	}
	
	@Test
	void getAllTest() {
		 List<Cliente> lista = dao.getAll();
		 assertNotEquals(0, lista.size());
	}
	
	@Test
	void getAllByEstadoTest() {
		List<Cliente> lista = dao.getAllByEstado("SP");
		assertNotEquals(0, lista.size());
		
		for(Cliente cliente : lista) {
			assertTrue(cliente.getEndereco().getEndereco().getCidade().getUf().contains("SP"));
		}
	}

	@Test
	void getAllByDiasReserva() {
		List<Cliente> lista = dao.getAllByDiasReserva(10);
		assertEquals(2, lista.size());
	}
}
