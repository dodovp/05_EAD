package br.com.fiap.test;

public class GenericDAOTest {

}
