package br.com.fiap.entitty;

public enum Posicao {

	ADC, SUP, MID, TOP, JUNGLE;
	
}
