package br.com.fiap.dao;

import br.com.fiap.exception.CommitException;
import br.com.fiap.exception.SearchNotFoundException;

public interface GenericDAO<T, K> {
	
	void create(T table);
	
	void update(T table);
	
	T read(K key) throws SearchNotFoundException;
				//K representa a chave prim�ria que vai ser utilizada pelo usu�rio
	void delete(K key) throws SearchNotFoundException;
				//key representa a chave prim�ria que vai ser utilizada pelo usu�rio
	
	void commit() throws CommitException;
	
}
