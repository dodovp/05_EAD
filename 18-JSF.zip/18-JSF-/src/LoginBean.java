import javax.faces.bean.ManagedBean;

@ManagedBean
public class LoginBean {
	private String nome;
	private String senha;
	 
	public void logar() {
		if("Salvador".equals(getNome())) {
			System.out.println("Usu�rio logado: "+ getNome());
		}else {
			System.out.println("Login falhou");
		}
	}
	
	public LoginBean() {
		super();
	}
	public LoginBean(String nome, String senha) {
		super();
		this.nome = nome;
		this.senha = senha;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}
	
		
}
